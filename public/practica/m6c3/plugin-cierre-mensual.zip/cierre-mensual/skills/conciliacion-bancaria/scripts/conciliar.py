#!/usr/bin/env python3
"""Conciliación bancaria: extracto del banco (CSV) frente al mayor de bancos (Excel).

Uso:
    python3 conciliar.py EXTRACTO.csv MAYOR.xlsx [--salida informe.md] [--tolerancia 5]

Qué hace:
  1. Lee el extracto (separador «;», decimales con coma, punto de millar) y el mayor
     (columnas Fecha, Asiento, Concepto, Debe, Haber, Saldo; fila «Saldo inicial»).
  2. Empareja los movimientos por importe exacto, con una tolerancia de fechas de
     ±N días (5 por defecto).
  3. Clasifica lo que no casa:
       - posibles duplicados en el mayor (mismo importe y mismo concepto repetidos);
       - posibles transposiciones (diferencia múltiplo de 9 céntimos y menor del 50 %);
       - partidas solo en el banco  -> asiento de ajuste (normas, 4.2);
       - partidas solo en el mayor  -> en tránsito, no se ajustan (normas, 4.3).
  4. Escribe un resumen en Markdown con saldos, partidas, ajustes propuestos y la
     comprobación final. No modifica los archivos de entrada.

Códigos de salida: 0 = cuadra; 2 = no cuadra (revisar); 1 = error de lectura o de uso.
Requisitos: Python 3.8 o posterior y la biblioteca openpyxl (pip install openpyxl).
"""

import argparse
import csv
import sys
import unicodedata
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

CENT = Decimal("0.01")


class ErrorConciliacion(Exception):
    """Error de lectura o de formato que impide conciliar."""


# --------------------------------------------------------------------------- utilidades

def normalizar(texto):
    """Minúsculas, sin acentos ni espacios dobles: para comparar cabeceras y conceptos."""
    if texto is None:
        return ""
    t = unicodedata.normalize("NFKD", str(texto))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return " ".join(t.lower().split())


def a_importe(valor, contexto):
    """Convierte «-6.800,00», «1.234,50 €», 1234.5 o None en Decimal con dos decimales."""
    if valor is None or valor == "":
        return Decimal("0.00")
    if isinstance(valor, (int, float, Decimal)):
        return Decimal(str(valor)).quantize(CENT)
    t = str(valor).strip().replace("€", "").replace(" ", "").replace(" ", "")
    t = t.replace("−", "-")  # signo menos tipográfico
    if "," in t:
        t = t.replace(".", "").replace(",", ".")
    try:
        return Decimal(t).quantize(CENT)
    except InvalidOperation:
        raise ErrorConciliacion("Importe no válido en {}: «{}»".format(contexto, valor))


def a_fecha(valor, contexto):
    """Acepta date/datetime o texto dd/mm/aaaa, dd-mm-aaaa o aaaa-mm-dd."""
    if isinstance(valor, datetime):
        return valor.date()
    if isinstance(valor, date):
        return valor
    t = str(valor or "").strip()
    for formato in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%y"):
        try:
            return datetime.strptime(t, formato).date()
        except ValueError:
            pass
    raise ErrorConciliacion("Fecha no válida en {}: «{}»".format(contexto, valor))


def euros(importe, signo=False):
    """1234567.8 -> «1.234.567,80»; con signo=True antepone + o −."""
    q = Decimal(importe).quantize(CENT)
    entero, dec = "{:.2f}".format(abs(q)).split(".")
    grupos = []
    while len(entero) > 3:
        grupos.insert(0, entero[-3:])
        entero = entero[:-3]
    grupos.insert(0, entero)
    texto = ".".join(grupos) + "," + dec
    if q < 0:
        return "−" + texto
    return ("+" + texto) if signo and q > 0 else texto


def fecha_txt(f):
    return f.strftime("%d/%m/%Y")


class Movimiento:
    def __init__(self, origen, fila, fecha, concepto, importe, ref=""):
        self.origen = origen      # «banco» o «mayor»
        self.fila = fila          # fila en el archivo de origen (para localizarla)
        self.fecha = fecha
        self.concepto = concepto
        self.importe = importe    # positivo = entrada de dinero; negativo = salida
        self.ref = ref            # número de asiento en el mayor
        self.pareja = None

    def etiqueta(self):
        ref = " (asiento {})".format(self.ref) if self.ref not in ("", None) else ""
        return "{} · {}{}".format(fecha_txt(self.fecha), self.concepto, ref)


# --------------------------------------------------------------------------- lectura

def columna(cabeceras, *candidatos, obligatoria=True, archivo=""):
    """Índice de la primera cabecera que empieza por alguno de los candidatos."""
    for i, c in enumerate(cabeceras):
        for cand in candidatos:
            if c.startswith(cand):
                return i
    if obligatoria:
        raise ErrorConciliacion("No encuentro la columna «{}» en {}. Cabeceras leídas: {}".format(
            candidatos[0], archivo, ", ".join(cabeceras)))
    return None


def leer_extracto(ruta):
    ruta = Path(ruta)
    if not ruta.is_file():
        raise ErrorConciliacion("No existe el extracto: {}".format(ruta))
    texto = None
    for codificacion in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            texto = ruta.read_text(encoding=codificacion)
            break
        except UnicodeDecodeError:
            continue
    lineas = [l for l in texto.splitlines() if l.strip()]
    if len(lineas) < 2:
        raise ErrorConciliacion("El extracto {} no tiene movimientos.".format(ruta.name))
    separador = ";" if lineas[0].count(";") >= lineas[0].count(",") else ","
    filas = list(csv.reader(lineas, delimiter=separador))
    cab = [normalizar(c) for c in filas[0]]
    i_fecha = columna(cab, "fecha operacion", "fecha", archivo=ruta.name)
    i_concepto = columna(cab, "concepto", "descripcion", archivo=ruta.name)
    i_importe = columna(cab, "importe", archivo=ruta.name)
    i_saldo = columna(cab, "saldo", obligatoria=False, archivo=ruta.name)

    movimientos = []
    saldos = []
    for n, fila in enumerate(filas[1:], start=2):
        if not any(c.strip() for c in fila):
            continue
        contexto = "{}, fila {}".format(ruta.name, n)
        mov = Movimiento("banco", n, a_fecha(fila[i_fecha], contexto), fila[i_concepto].strip(),
                         a_importe(fila[i_importe], contexto))
        movimientos.append(mov)
        if i_saldo is not None and fila[i_saldo].strip():
            saldos.append(a_importe(fila[i_saldo], contexto))
    if i_saldo is None or len(saldos) != len(movimientos):
        raise ErrorConciliacion("El extracto {} necesita la columna Saldo en todas las filas.".format(ruta.name))
    saldo_inicial = saldos[0] - movimientos[0].importe
    saldo_final = saldos[-1]
    # coherencia interna del extracto
    acumulado = saldo_inicial
    for mov, saldo in zip(movimientos, saldos):
        acumulado += mov.importe
        if acumulado != saldo:
            raise ErrorConciliacion("El saldo del extracto no cuadra en la fila {} ({} frente a {}).".format(
                mov.fila, euros(acumulado), euros(saldo)))
    return movimientos, saldo_inicial, saldo_final


def leer_mayor(ruta):
    ruta = Path(ruta)
    if not ruta.is_file():
        raise ErrorConciliacion("No existe el mayor: {}".format(ruta))
    try:
        import openpyxl
    except ImportError:
        raise ErrorConciliacion(
            "Falta la biblioteca openpyxl, necesaria para leer el Excel del mayor. "
            "Instálala con: pip install openpyxl")
    try:
        libro = openpyxl.load_workbook(ruta, data_only=True, read_only=True)
    except Exception as e:  # archivo dañado, abierto o con otro formato
        raise ErrorConciliacion("No puedo abrir {}: {}".format(ruta.name, e))

    for hoja in libro.worksheets:
        filas = list(hoja.iter_rows(values_only=True))
        for n, fila in enumerate(filas):
            cab = [normalizar(c) for c in fila]
            if any(c == "fecha" for c in cab) and any(c.startswith("debe") for c in cab):
                return _movimientos_mayor(ruta.name, hoja.title, filas, n, cab)
    raise ErrorConciliacion("No encuentro en {} una fila de cabecera con «Fecha» y «Debe».".format(ruta.name))


def _movimientos_mayor(nombre, hoja, filas, n_cab, cab):
    i_fecha = columna(cab, "fecha", archivo=nombre)
    i_asiento = columna(cab, "asiento", obligatoria=False, archivo=nombre)
    i_concepto = columna(cab, "concepto", archivo=nombre)
    i_debe = columna(cab, "debe", archivo=nombre)
    i_haber = columna(cab, "haber", archivo=nombre)
    i_saldo = columna(cab, "saldo", obligatoria=False, archivo=nombre)

    movimientos = []
    saldo_inicial = None
    ultimo_saldo = None
    for n, fila in enumerate(filas[n_cab + 1:], start=n_cab + 2):
        if fila is None or all(v in (None, "") for v in fila):
            continue
        contexto = "{} (hoja {}), fila {}".format(nombre, hoja, n)
        concepto = str(fila[i_concepto] or "").strip()
        saldo = a_importe(fila[i_saldo], contexto) if i_saldo is not None and fila[i_saldo] not in (None, "") else None
        if normalizar(concepto).startswith("saldo inicial"):
            saldo_inicial = saldo
            continue
        if fila[i_fecha] in (None, ""):
            continue  # filas de totales o notas
        importe = a_importe(fila[i_debe], contexto) - a_importe(fila[i_haber], contexto)
        ref = fila[i_asiento] if i_asiento is not None else ""
        movimientos.append(Movimiento("mayor", n, a_fecha(fila[i_fecha], contexto), concepto, importe, ref))
        if saldo is not None:
            ultimo_saldo = saldo
    if not movimientos:
        raise ErrorConciliacion("El mayor {} no tiene movimientos.".format(nombre))
    if saldo_inicial is None:
        raise ErrorConciliacion("El mayor {} no tiene la fila «Saldo inicial».".format(nombre))
    saldo_calculado = saldo_inicial + sum(m.importe for m in movimientos)
    if ultimo_saldo is not None and ultimo_saldo != saldo_calculado:
        raise ErrorConciliacion("El saldo del mayor no cuadra con sus movimientos ({} frente a {}).".format(
            euros(ultimo_saldo), euros(saldo_calculado)))
    return movimientos, saldo_inicial, saldo_calculado


# --------------------------------------------------------------------------- conciliación

def emparejar(banco, mayor, tolerancia):
    """Empareja por importe exacto y fecha dentro de la tolerancia (la más cercana gana)."""
    for m in mayor:
        candidatos = [b for b in banco if b.pareja is None and b.importe == m.importe
                      and abs((b.fecha - m.fecha).days) <= tolerancia]
        if candidatos:
            b = min(candidatos, key=lambda x: (abs((x.fecha - m.fecha).days), x.fila))
            b.pareja, m.pareja = m, b


def conciliar(banco, mayor, tolerancia):
    emparejar(banco, mayor, tolerancia)
    sin_banco = [b for b in banco if b.pareja is None]
    sin_mayor = [m for m in mayor if m.pareja is None]

    # 1. duplicados: el mismo importe y el mismo concepto aparecen más de una vez en el mayor
    duplicados = []
    for m in list(sin_mayor):
        gemelos = [o for o in mayor if o is not m and o.importe == m.importe
                   and normalizar(o.concepto) == normalizar(m.concepto)]
        if gemelos:
            duplicados.append((m, gemelos[0]))
            sin_mayor.remove(m)

    # 2. transposiciones: mismo signo, diferencia múltiplo de 9 céntimos y menor del 50 %
    pares = []
    for b in sin_banco:
        for m in sin_mayor:
            dif = b.importe - m.importe
            centimos = int((dif * 100).to_integral_value())
            if (dif != 0 and (b.importe > 0) == (m.importe > 0) and centimos % 9 == 0
                    and abs(dif) < abs(b.importe) / 2 and abs((b.fecha - m.fecha).days) <= tolerancia):
                pares.append((abs(dif), b, m))
    transposiciones = []
    for _, b, m in sorted(pares, key=lambda p: (p[0], p[1].fila)):
        if b in sin_banco and m in sin_mayor:
            transposiciones.append((b, m))
            sin_banco.remove(b)
            sin_mayor.remove(m)

    return {
        "emparejados": [m for m in mayor if m.pareja is not None],
        "solo_banco": sin_banco,
        "duplicados": duplicados,
        "transposiciones": transposiciones,
        "transito": sin_mayor,
    }


# --------------------------------------------------------------------------- informe

def informe(res, banco, mayor, saldos, archivos, tolerancia):
    si_b, sf_b, si_m, sf_m = saldos
    ajustes = []  # (texto, importe del ajuste en la contabilidad)
    for b in sorted(res["solo_banco"], key=lambda x: (x.fecha, x.fila)):
        ajustes.append(("Solo en el banco: {} → asiento de ajuste (4.2)".format(b.etiqueta()), b.importe))
    for m, gemelo in res["duplicados"]:
        ajustes.append(("Duplicado en el mayor: {} → anular el duplicado".format(m.etiqueta()), -m.importe))
    for b, m in res["transposiciones"]:
        ajustes.append(("Transposición: {} → corregir el asiento".format(m.etiqueta()), b.importe - m.importe))
    total_ajustes = sum((a[1] for a in ajustes), Decimal("0.00"))
    total_transito = sum((m.importe for m in res["transito"]), Decimal("0.00"))
    ajustado = sf_m + total_ajustes
    resultado = ajustado - total_transito
    cuadra = resultado == sf_b and si_b == si_m

    o = []
    o.append("# Conciliación bancaria")
    o.append("")
    o.append("Extracto: `{}` ({} movimientos) · Mayor: `{}` ({} movimientos) · Tolerancia de fechas: ±{} días".format(
        archivos[0], len(banco), archivos[1], len(mayor), tolerancia))
    o.append("")
    o.append("## Saldos")
    o.append("")
    o.append("| Concepto | Banco (€) | Contabilidad (€) |")
    o.append("|---|---:|---:|")
    o.append("| Saldo inicial | {} | {} |".format(euros(si_b), euros(si_m)))
    o.append("| Saldo final | {} | {} |".format(euros(sf_b), euros(sf_m)))
    o.append("")
    o.append("Diferencia de saldos finales (banco − contabilidad): **{} €**.".format(euros(sf_b - sf_m, True)))
    if si_b != si_m:
        o.append("")
        o.append("**Atención:** los saldos iniciales no coinciden; revisa la conciliación del mes anterior.")
    o.append("")
    o.append("Movimientos emparejados por importe y fecha: {} de {} en el mayor.".format(
        len(res["emparejados"]), len(mayor)))
    o.append("")
    o.append("## Partidas por conciliar")
    o.append("")
    o.append("| # | Tipo | Fecha | Concepto | Banco (€) | Mayor (€) | Tratamiento |")
    o.append("|---|---|---|---|---:|---:|---|")
    n = 0
    for b in sorted(res["solo_banco"], key=lambda x: (x.fecha, x.fila)):
        n += 1
        o.append("| {} | Solo en el banco | {} | {} | {} | — | Asiento de ajuste (4.2) |".format(
            n, fecha_txt(b.fecha), b.concepto, euros(b.importe)))
    for m, gemelo in res["duplicados"]:
        n += 1
        o.append("| {} | Posible duplicado | {} | {} (asientos {} y {}) | {} (una vez) | {} (dos veces) | Anular el duplicado |".format(
            n, fecha_txt(m.fecha), m.concepto, gemelo.ref, m.ref, euros(m.importe), euros(m.importe)))
    for b, m in res["transposiciones"]:
        n += 1
        o.append("| {} | Posible transposición | {} | {} (asiento {}) | {} | {} | Diferencia {} € divisible entre 9 (4.4): corregir el asiento |".format(
            n, fecha_txt(m.fecha), m.concepto, m.ref, euros(b.importe), euros(m.importe), euros(b.importe - m.importe, True)))
    for m in sorted(res["transito"], key=lambda x: (x.fecha, x.fila)):
        n += 1
        o.append("| {} | Solo en el mayor | {} | {} (asiento {}) | — | {} | En tránsito: no se ajusta, se lista (4.3) |".format(
            n, fecha_txt(m.fecha), m.concepto, m.ref, euros(m.importe)))
    if n == 0:
        o.append("| — | — | — | Sin partidas por conciliar | — | — | — |")
    o.append("")
    o.append("## Ajustes contables propuestos")
    o.append("")
    o.append("| # | Ajuste | Importe (€) |")
    o.append("|---|---|---:|")
    for i, (texto, imp) in enumerate(ajustes, start=1):
        o.append("| {} | {} | {} |".format(i, texto, euros(imp, True)))
    o.append("| | **Total de ajustes** | **{}** |".format(euros(total_ajustes, True)))
    o.append("")
    o.append("Partidas en tránsito (no se ajustan): **{} €**.".format(euros(total_transito, True)))
    o.append("")
    o.append("## Comprobación")
    o.append("")
    o.append("| Paso | Importe (€) |")
    o.append("|---|---:|")
    o.append("| Saldo contable | {} |".format(euros(sf_m)))
    o.append("| + Ajustes propuestos | {} |".format(euros(total_ajustes, True)))
    o.append("| = Saldo contable ajustado | {} |".format(euros(ajustado)))
    o.append("| − Partidas en tránsito | {} |".format(euros(-total_transito, True)))
    o.append("| = Saldo conciliado | {} |".format(euros(resultado)))
    o.append("| Saldo según el banco | {} |".format(euros(sf_b)))
    o.append("")
    if cuadra:
        o.append("**Resultado: CUADRA.** El saldo conciliado coincide con el del banco.")
    else:
        o.append("**Resultado: NO CUADRA.** Quedan {} € sin explicar: revisa las partidas antes de proponer los ajustes.".format(
            euros(sf_b - resultado, True)))
    o.append("")
    o.append("Este informe propone ajustes; no modifica el extracto ni el mayor. Los asientos los registra una persona.")
    return "\n".join(o) + "\n", cuadra


# --------------------------------------------------------------------------- principal

def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    p = argparse.ArgumentParser(description="Concilia el extracto bancario (CSV) con el mayor de bancos (Excel).")
    p.add_argument("extracto", help="extracto del banco en CSV (separador ;, decimales con coma)")
    p.add_argument("mayor", help="mayor de la cuenta de bancos en Excel (.xlsx)")
    p.add_argument("--salida", help="archivo Markdown donde guardar el informe (opcional)")
    p.add_argument("--tolerancia", type=int, default=5, help="días de diferencia admitidos al emparejar (5 por defecto)")
    args = p.parse_args(argv)
    try:
        banco, si_b, sf_b = leer_extracto(args.extracto)
        mayor, si_m, sf_m = leer_mayor(args.mayor)
        res = conciliar(banco, mayor, args.tolerancia)
        texto, cuadra = informe(res, banco, mayor, (si_b, sf_b, si_m, sf_m),
                                (Path(args.extracto).name, Path(args.mayor).name), args.tolerancia)
    except ErrorConciliacion as e:
        print("ERROR: {}".format(e), file=sys.stderr)
        return 1
    print(texto)
    if args.salida:
        try:
            Path(args.salida).write_text(texto, encoding="utf-8")
        except OSError as e:
            print("ERROR: no puedo escribir {}: {}".format(args.salida, e), file=sys.stderr)
            return 1
    return 0 if cuadra else 2


if __name__ == "__main__":
    sys.exit(main())
